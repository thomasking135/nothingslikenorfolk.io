$(button).click(function() {
    $(this).css('background', '#ff0000');
)};